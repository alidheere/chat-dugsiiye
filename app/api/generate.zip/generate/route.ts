
export async function POST(req: Request) {
  try {
    const { topic } = await req.json();

    if (!topic || typeof topic !== "string") {
      return Response.json(
        { success: false, message: "Topic is required" },
        { status: 400 }
      );
    }

    const response = await fetch(
      "https://openrouter.ai/api/v1/chat/completions",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "openai/gpt-4o-mini",
          messages: [
            {
              role: "system",
              content:
                "You are a professional blog writer. Write clear, informative and SEO-friendly blog posts with headings.",
            },
            {
              role: "user",
              content: `Write a detailed blog post about: ${topic}`,
            },
          ],
        }),
      }
    );

    if (!response.ok) {
      const error = await response.text();
      console.error("OpenRouter error:", error);

      return Response.json(
        { success: false, message: "AI generation failed" },
        { status: response.status }
      );
    }

    const data = await response.json();

    const blog = data.choices?.[0]?.message?.content;

    return Response.json({
      success: true,
      blog,
    });
  } catch (error) {
    console.error("Generate error:", error);

    return Response.json(
      { success: false, message: "Something went wrong" },
      { status: 500 }
    );
  }
}
